package com.beren.rcwardrobe.service;

import android.os.RemoteException;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.content.Context;
import org.json.*;
import com.beren.rcwardrobe.IFileScanService;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Shizuku UserService: scans RC local data without requiring MANAGE_EXTERNAL_STORAGE. */
public class FileScanService extends IFileScanService.Stub {
    private final Context context;
    private volatile MatcherCatalog matcherCatalog;
    public FileScanService() { this.context = null; }
    public FileScanService(Context context) { this.context = context; }
    private static final Pattern ITEM = Pattern.compile(
            "story(\\d+)(clothes|hair|trinket|face\\d*makeup|makeup|overlay)(\\d+)(?:[a-zA-Z]+|\\+\\d+)*",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern STORY = Pattern.compile("story(\\d+)", Pattern.CASE_INSENSITIVE);
    private static final Pattern WARDROBE_WORD = Pattern.compile(
            "wardrobe|clothes|hair|trinket|makeup|outfit|hairstyle|acomp|apks|inventory|owned",
            Pattern.CASE_INSENSITIVE);

    private static final int CHUNK = 1024 * 1024;
    private static final int OVERLAP = 4096;
    private static final int MAX_DETAIL_FILES = 250;
    private static final int MAX_CANDIDATE_FILES = 300;
    private static final int MAX_DB_TABLES = 200;
    private static final int MAX_DB_ROWS_PER_TABLE = 25;
    private static final int MAX_IDS_RETURNED = 4000;
    private static final int MAX_EVIDENCE = 800;
    private static final int MAX_ACCOUNT_EVIDENCE = 400;
    private static final int MAX_ACCOUNT_PAIRS = 800;
    private static final int MAX_EVIDENCE_SUMMARIES = 4000;
    private static final int CONTEXT_CHARS = 220;
    private static final long LARGE_BINARY_LIMIT = 256L * 1024L * 1024L;
    private static final long MAX_UNITYFS_FILE = 512L * 1024L * 1024L;
    private static final int UNITYFS_MAX_INFO = 16 * 1024 * 1024;

    // We want game data, not photos/audio/video/downloads accidentally nested in the package.
    private static final Set<String> TEXT_EXT = new HashSet<>(Arrays.asList(
            "json","txt","xml","bytes","csv","db","sqlite","sqlite3","dat","bin","asset","assets","bundle","resS","resource"
    ));
    private static final Set<String> SKIP_EXT = new HashSet<>(Arrays.asList(
            "png","jpg","jpeg","webp","gif","mp3","ogg","wav","mp4","m4a","webm","aac","zip","apk","dex","so","ttf","otf"
    ));

    @Override
    public String scan(String root) throws RemoteException {
        File base = new File(root);
        if (!base.exists() || !base.isDirectory()) return "ROOT_NOT_FOUND|" + root;

        ScanState s = new ScanState();
        walk(base, s, 0);

        StringBuilder out = new StringBuilder();
        out.append("ROOT|").append(base.getAbsolutePath()).append('\n');
        out.append("FILES|").append(s.files).append('\n');
        out.append("SCANNED_FILES|").append(s.scannedFiles).append('\n');
        out.append("SKIPPED_FILES|").append(s.skippedFiles).append('\n');
        out.append("BYTES|").append(s.bytes).append('\n');
        out.append("SCANNED_BYTES|").append(s.scannedBytes).append('\n');
        out.append("HITS|").append(s.uniqueItems.size()).append('\n');
        out.append("STORY_IDS|").append(s.storyIds.size()).append('\n');
        out.append("WARDROBE_KEYWORD_FILES|").append(s.keywordFiles).append('\n');
        out.append("DB_FILES|").append(s.dbFiles).append('\n');
        out.append("UNITY_BUNDLES|").append(s.unityBundles).append('\n');
        out.append("UNITY_BLOCKS|").append(s.unityBlocks).append('\n');
        out.append("UNITY_BYTES|").append(s.unityBytes).append('\n');
        out.append("UNITY_KEYWORD_BUNDLES|").append(s.unityKeywordBundles).append('\n');
        out.append("UNITY_ERRORS|").append(s.unityErrors).append('\n');
        out.append("DB_TABLES|").append(s.dbTables).append('\n');
        out.append("DB_WARDROBE_TABLES|").append(s.dbWardrobeTables).append('\n');
        out.append("REPORT_PATH|/storage/emulated/0/Download/RC_Gardrop_Tarama_Raporu.txt").append('\n');
        out.append("ERRORS|").append(s.errors).append('\n');
        out.append("TRUNCATED_IDS|").append(s.uniqueItems.size() > MAX_IDS_RETURNED ? 1 : 0).append('\n');
        out.append("EVIDENCE|").append(s.evidence.size()).append('\n');
        out.append("ACCOUNT_FILES|").append(s.accountFiles).append('\n');
        out.append("ACCOUNT_ACOMP|").append(s.accountAcomp.size()).append('\n');
        out.append("ACCOUNT_APKS|").append(s.accountApks.size()).append('\n');
        out.append("ACCOUNT_PAIRS|").append(s.accountPairs.size()).append('\n');
        loadMatcherCatalog();
        for (String id : s.uniqueItems) {
            String m = matcherCatalog == null ? null : matcherCatalog.match(id);
            if (m != null) s.matches.add(m);
        }
        out.append("CATALOG_MATCHES|").append(s.matches.size()).append('\n');
        buildEvidenceSummaries(s);
        out.append("EVIDENCE_SUMMARIES|").append(s.evidenceSummaries.size()).append('\n');

        out.append("STORIES|").append(join(s.storyIds)).append('\n');
        out.append("IDS|").append(joinLimited(s.uniqueItems, MAX_IDS_RETURNED)).append('\n');
        for (String detail : s.details) out.append("FILE|").append(detail).append('\n');
        for (String candidate : s.candidates) out.append("CANDIDATE|").append(candidate).append('\n');
        for (String evidence : s.evidence) out.append("EVIDENCE_ITEM|").append(evidence).append('\n');
        for (String x : s.accountAcomp) out.append("ACCOUNT_ACOMP_ITEM|").append(x).append('\n');
        for (String x : s.accountApks) out.append("ACCOUNT_APK_ITEM|").append(x).append('\n');
        for (String x : s.accountPairs) out.append("ACCOUNT_PAIR_ITEM|").append(x).append('\n');
        for (String x : s.matches) out.append("CATALOG_MATCH_ITEM|").append(x).append('\n');
        for (String x : s.evidenceSummaries) out.append("EVIDENCE_SUMMARY_ITEM|").append(x).append('\n');
        writeReport(base, s);
        return out.toString();
    }

    private void walk(File dir, ScanState s, int depth) {
        if (depth > 80) return;
        File[] children;
        try { children = dir.listFiles(); } catch (Throwable t) { s.errors++; return; }
        if (children == null) return;

        for (File f : children) {
            if (f.isDirectory()) { walk(f, s, depth + 1); continue; }
            s.files++;
            long len = Math.max(0L, f.length());
            s.bytes += len;

            String lower = f.getName().toLowerCase(Locale.ROOT);
            String ext = extension(lower);
            boolean db = lower.endsWith(".db") || lower.endsWith(".sqlite") || lower.endsWith(".sqlite3") || lower.contains("database");
            if (db) s.dbFiles++;

            // Always inspect filenames. For content, prioritize game-data files and small unknown files.
            LinkedHashSet<String> hits = new LinkedHashSet<>();
            LinkedHashSet<String> stories = new LinkedHashSet<>();
            addMatches(f.getName(), hits, stories);

            boolean shouldScan = !SKIP_EXT.contains(ext) && (TEXT_EXT.contains(ext) || len <= LARGE_BINARY_LIMIT || db);
            if (db && len > 0 && len <= LARGE_BINARY_LIMIT) {
                inspectSqlite(f, s, hits, stories);
            }

            if (shouldScan && len > 0) {
                s.scannedFiles++;
                if (lower.equals("account.json") || lower.contains("account")) {
                    s.accountFiles++;
                    inspectAccountLikeFile(f, s);
                }
                s.scannedBytes += len;
                try {
                    ScanFileResult r = scanStreaming(f, hits, stories, s);
                    if (r.keyword) {
                        s.keywordFiles++;
                        if (s.candidates.size() < MAX_CANDIDATE_FILES) s.candidates.add(f.getAbsolutePath() + "|" + len);
                    }
                    if (isUnityFs(f) && len <= MAX_UNITYFS_FILE) {
                        BundleScanResult br = scanUnityFs(f, hits, stories);
                        if (br.blocks > 0) {
                            s.unityBundles++;
                            s.unityBlocks += br.blocks;
                            s.unityBytes += br.bytes;
                            if (br.keyword) s.unityKeywordBundles++;
                            if (br.error != null) s.unityErrors++;
                        }
                    }
                } catch (Throwable t) { s.errors++; }
            } else {
                s.skippedFiles++;
            }

            s.uniqueItems.addAll(hits);
            s.storyIds.addAll(stories);
            if (!hits.isEmpty() && s.details.size() < MAX_DETAIL_FILES) {
                s.details.add(f.getAbsolutePath() + "|" + len + "|" + join(hits));
            }
        }
    }

    private ScanFileResult scanStreaming(File file, Set<String> hits, Set<String> stories, ScanState state) throws IOException {
        boolean keyword = false;
        try (InputStream in = new BufferedInputStream(new FileInputStream(file), CHUNK)) {
            byte[] buf = new byte[CHUNK];
            byte[] carry = new byte[OVERLAP];
            int carryLen = 0;
            int read;
            while ((read = in.read(buf)) != -1) {
                byte[] combined = new byte[carryLen + read];
                System.arraycopy(carry, 0, combined, 0, carryLen);
                System.arraycopy(buf, 0, combined, carryLen, read);

                String utf8 = new String(combined, StandardCharsets.UTF_8);
                if (containsKeyword(utf8)) keyword = true;
                find(utf8, hits, stories);
                collectEvidence(utf8, file, state);

                // Many Unity/serialized resources contain UTF-16LE strings.
                String utf16 = new String(combined, StandardCharsets.UTF_16LE);
                if (containsKeyword(utf16)) keyword = true;
                find(utf16, hits, stories);
                collectEvidence(utf16, file, state);

                carryLen = Math.min(OVERLAP, combined.length);
                System.arraycopy(combined, combined.length - carryLen, carry, 0, carryLen);
            }
        }
        return new ScanFileResult(keyword);
    }

    private void inspectAccountLikeFile(File file, ScanState state) {
        // Parse account.json as JSON so each acomp array can be correlated with its sibling apks array.
        // Only wardrobe-shaped identifiers and numeric APK references are retained.
        try {
            long len = file.length();
            if (len <= 0 || len > 64L * 1024L * 1024L) return;
            byte[] data = new byte[(int) len];
            try (InputStream in = new BufferedInputStream(new FileInputStream(file))) {
                int off = 0, n;
                while (off < data.length && (n = in.read(data, off, data.length - off)) > 0) off += n;
            }
            Object root = new JSONTokener(new String(data, StandardCharsets.UTF_8)).nextValue();
            walkAccountJson(root, "root", state);
        } catch (Throwable ignored) {
            try {
                byte[] data = java.nio.file.Files.readAllBytes(file.toPath());
                collectAccountArrays(new String(data, StandardCharsets.UTF_8), state);
            } catch (Throwable ignored2) {}
        }
    }

    private void walkAccountJson(Object value, String path, ScanState state) {
        if (value instanceof JSONObject) {
            JSONObject o = (JSONObject) value;
            // RC uses acomp/apks as well as numbered variants such as acomp1/apks1 and acomp2/apks2.
            // Treat each suffix as its own pair so newer/alternate appearance groups are not silently lost.
            ArrayList<String> acompKeys = new ArrayList<>();
            Iterator<String> keyIt = o.keys();
            while (keyIt.hasNext()) {
                String k = keyIt.next();
                if (k.matches("acomp\\d*")) acompKeys.add(k);
            }
            for (String acompKey : acompKeys) {
                String suffix = acompKey.substring(5);
                JSONArray acomp = o.optJSONArray(acompKey);
                JSONArray apks = o.optJSONArray("apks" + suffix);
                if (acomp == null) continue;
                ArrayList<String> itemIds = new ArrayList<>();
                for (int i=0;i<acomp.length();i++) {
                    String v = acomp.optString(i, "");
                    if (ITEM.matcher(v).matches()) {
                        String id = v.toLowerCase(Locale.ROOT);
                        itemIds.add(id);
                        if (state.accountAcomp.size() < MAX_ACCOUNT_EVIDENCE) state.accountAcomp.add(id);
                    }
                }
                ArrayList<String> apkIds = new ArrayList<>();
                if (apks != null) {
                    for (int i=0;i<apks.length();i++) {
                        String v = apks.optString(i, "");
                        if (v.matches("\\d+")) {
                            apkIds.add(v);
                            if (state.accountApks.size() < MAX_ACCOUNT_EVIDENCE) state.accountApks.add(v);
                        }
                    }
                }
                if (!itemIds.isEmpty() && state.accountPairs.size() < MAX_ACCOUNT_PAIRS) {
                    int n = Math.min(itemIds.size(), apkIds.size());
                    for (int i=0;i<n && state.accountPairs.size()<MAX_ACCOUNT_PAIRS;i++)
                        state.accountPairs.add(itemIds.get(i) + "=>" + apkIds.get(i) + "|array=" + acompKey + "|path=" + path);
                    if (itemIds.size() != apkIds.size() && state.accountPairs.size() < MAX_ACCOUNT_PAIRS)
                        state.accountPairs.add("ARRAY_LENGTH_MISMATCH|" + acompKey + "=" + itemIds.size() + "|apks" + suffix + "=" + apkIds.size() + "|path=" + path);
                }
            }
            Iterator<String> keys = o.keys();
            while (keys.hasNext()) {
                String k = keys.next();
                Object child = o.opt(k);
                if (child instanceof JSONObject || child instanceof JSONArray) walkAccountJson(child, path + "." + k, state);
            }
        } else if (value instanceof JSONArray) {
            JSONArray a = (JSONArray) value;
            for (int i=0;i<a.length();i++) {
                Object child = a.opt(i);
                if (child instanceof JSONObject || child instanceof JSONArray) walkAccountJson(child, path + "[" + i + "]", state);
            }
        }
    }

    private void collectAccountArrays(String text, ScanState state) {
        Matcher acomp = Pattern.compile("\\\"acomp\\d*\\\"\\s*:\\s*\\[(.*?)\\]", Pattern.CASE_INSENSITIVE | Pattern.DOTALL).matcher(text);
        while (acomp.find() && state.accountAcomp.size() < MAX_ACCOUNT_EVIDENCE) {
            Matcher ids = ITEM.matcher(acomp.group(1));
            while (ids.find() && state.accountAcomp.size() < MAX_ACCOUNT_EVIDENCE)
                state.accountAcomp.add(ids.group().toLowerCase(Locale.ROOT));
        }
        Matcher apks = Pattern.compile("\\\"apks\\d*\\\"\\s*:\\s*\\[(.*?)\\]", Pattern.CASE_INSENSITIVE | Pattern.DOTALL).matcher(text);
        while (apks.find() && state.accountApks.size() < MAX_ACCOUNT_EVIDENCE) {
            Matcher ids = Pattern.compile("\\\"([0-9]+)\\\"").matcher(apks.group(1));
            while (ids.find() && state.accountApks.size() < MAX_ACCOUNT_EVIDENCE)
                state.accountApks.add(ids.group(1));
        }
    }

    private void collectEvidence(String text, File file, ScanState state) {
        if (state.evidence.size() >= MAX_EVIDENCE) return;
        Matcher m = ITEM.matcher(text);
        while (m.find() && state.evidence.size() < MAX_EVIDENCE) {
            int a = Math.max(0, m.start() - CONTEXT_CHARS);
            int z = Math.min(text.length(), m.end() + CONTEXT_CHARS);
            String ctx = text.substring(a, z).replace('\n',' ').replace('\r',' ').replace('\t',' ');
            while (ctx.contains("  ")) ctx = ctx.replace("  ", " ");
            state.evidence.add(file.getAbsolutePath() + "|" + m.group().toLowerCase(Locale.ROOT) + "|" + ctx);
        }
    }

    private void buildEvidenceSummaries(ScanState s) {
        if (!s.evidenceSummaries.isEmpty()) return;
        LinkedHashMap<String, EvidenceAgg> map = new LinkedHashMap<>();
        for (String e : s.evidence) {
            String[] p = e.split("\\|", 3);
            if (p.length < 3) continue;
            EvidenceAgg a = map.get(p[1]);
            if (a == null) { a = new EvidenceAgg(); map.put(p[1], a); }
            a.files.add(p[0]);
            String ctx = p[2].toLowerCase(Locale.ROOT);
            if (Pattern.compile("\\b(owned|unlocked|acquired|purchased|collected|obtained)\\s*[:=]\\s*(true|1|yes)\\b").matcher(ctx).find()) a.trueSignals++;
            if (Pattern.compile("\\b(owned|unlocked|acquired|purchased|collected|obtained)\\s*[:=]\\s*(false|0|no)\\b").matcher(ctx).find()) a.falseSignals++;
        }
        for (Map.Entry<String,EvidenceAgg> en : map.entrySet()) {
            EvidenceAgg a = en.getValue();
            int score = Math.min(8, a.files.size()) + a.trueSignals * 4 - a.falseSignals * 4;
            String state;
            if (a.trueSignals > 0 && a.falseSignals > 0) state = "CONFLICT_REVIEW";
            else if (a.trueSignals > 0) state = "OWNERSHIP_SIGNAL";
            else if (a.falseSignals > 0) state = "NON_OWNERSHIP_SIGNAL";
            else if (a.files.size() >= 2) state = "MULTI_SOURCE_EVIDENCE";
            else state = "OBSERVED_ONLY";
            s.evidenceSummaries.add(en.getKey()+"|state="+state+"|score="+score+"|files="+a.files.size()+"|true="+a.trueSignals+"|false="+a.falseSignals);
            if (s.evidenceSummaries.size() >= MAX_EVIDENCE_SUMMARIES) break;
        }
    }

    private boolean containsKeyword(String text) { return WARDROBE_WORD.matcher(text).find(); }
    private void addMatches(String text, Set<String> hits, Set<String> stories) { find(text, hits, stories); }

    private void find(String text, Set<String> hits, Set<String> stories) {
        Matcher sm = STORY.matcher(text);
        while (sm.find()) stories.add(sm.group(1));
        Matcher im = ITEM.matcher(text);
        while (im.find()) hits.add(im.group().toLowerCase(Locale.ROOT));
    }

    private String extension(String name) {
        int p = name.lastIndexOf('.');
        return p >= 0 && p + 1 < name.length() ? name.substring(p + 1) : "";
    }

    private String join(Collection<String> c) { return joinLimited(c, Integer.MAX_VALUE); }
    private String joinLimited(Collection<String> c, int max) {
        StringBuilder b = new StringBuilder();
        boolean first = true;
        int n = 0;
        for (String x : c) {
            if (n++ >= max) break;
            if (!first) b.append(',');
            first = false;
            b.append(x);
        }
        return b.toString();
    }

    private void writeReport(File base, ScanState s) {
        File report = new File("/storage/emulated/0/Download/RC_Gardrop_Tarama_Raporu.txt");
        try (Writer w = new OutputStreamWriter(new FileOutputStream(report), StandardCharsets.UTF_8)) {
            w.write("RC Gardırop Dedektörü v1.0\n");
            w.write("ROOT=" + base.getAbsolutePath() + "\n");
            w.write("FILES=" + s.files + "\n");
            w.write("SCANNED_FILES=" + s.scannedFiles + "\n");
            w.write("SKIPPED_FILES=" + s.skippedFiles + "\n");
            w.write("BYTES=" + s.bytes + "\n");
            w.write("SCANNED_BYTES=" + s.scannedBytes + "\n");
            w.write("HITS=" + s.uniqueItems.size() + "\n");
            w.write("STORY_IDS=" + s.storyIds.size() + "\n");
            w.write("KEYWORD_FILES=" + s.keywordFiles + "\n");
            w.write("DB_FILES=" + s.dbFiles + "\n");
            w.write("UNITY_BUNDLES=" + s.unityBundles + "\n");
            w.write("UNITY_BLOCKS=" + s.unityBlocks + "\n");
            w.write("UNITY_BYTES=" + s.unityBytes + "\n");
            w.write("UNITY_KEYWORD_BUNDLES=" + s.unityKeywordBundles + "\n");
            w.write("UNITY_ERRORS=" + s.unityErrors + "\n");
            w.write("DB_TABLES=" + s.dbTables + "\n");
            w.write("DB_WARDROBE_TABLES=" + s.dbWardrobeTables + "\n");
            w.write("ERRORS=" + s.errors + "\n");
            w.write("EVIDENCE=" + s.evidence.size() + "\n");
            w.write("ACCOUNT_FILES=" + s.accountFiles + "\n");
            w.write("ACCOUNT_ACOMP=" + s.accountAcomp.size() + "\n");
            w.write("ACCOUNT_APKS=" + s.accountApks.size() + "\n");
            w.write("ACCOUNT_PAIRS=" + s.accountPairs.size() + "\n\n");
            w.write("STORIES\n" + join(s.storyIds) + "\n\n");
            w.write("IDS\n" + joinLimited(s.uniqueItems, MAX_IDS_RETURNED) + "\n\n");
            w.write("CANDIDATE_FILES\n");
            for (String x : s.candidates) w.write(x + "\n");
            w.write("\nDB_SCHEMA_AND_ROWS\n");
            for (String x : s.dbDetails) w.write(x + "\n");
            w.write("\nACCOUNT_ACOMP_APKS_PAIRS\n");
            for (String x : s.accountPairs) w.write(x + "\n");
            w.write("\nITEM_EVIDENCE\n");
            for (String x : s.evidence) w.write(x + "\n");
            w.write("\nFILES_WITH_IDS\n");
            for (String x : s.details) w.write(x + "\n");
        } catch (Throwable ignored) {}
    }

    private void inspectSqlite(File file, ScanState s, Set<String> hits, Set<String> stories) {
        SQLiteDatabase db = null;
        try {
            db = SQLiteDatabase.openDatabase(file.getAbsolutePath(), null, SQLiteDatabase.OPEN_READONLY);
            Cursor c = db.rawQuery("SELECT name, sql FROM sqlite_master WHERE type='table' ORDER BY name", null);
            int count = 0;
            while (c.moveToNext() && count++ < MAX_DB_TABLES) {
                String table = c.getString(0);
                String sql = c.isNull(1) ? "" : c.getString(1);
                s.dbTables++;
                boolean wardrobe = WARDROBE_WORD.matcher(table + " " + sql).find();
                if (wardrobe) s.dbWardrobeTables++;
                if (s.dbDetails.size() < MAX_DETAIL_FILES && (wardrobe || sql.toLowerCase(Locale.ROOT).contains("story"))) {
                    s.dbDetails.add("TABLE|" + table + "|" + sql.replace('\n',' '));
                }
                if (wardrobe) {
                    String safe = table.replace("'", "''");
                    try (Cursor rows = db.rawQuery("SELECT * FROM '" + safe + "' LIMIT " + MAX_DB_ROWS_PER_TABLE, null)) {
                        StringBuilder head = new StringBuilder("ROW|" + table + "|");
                        String[] cols = rows.getColumnNames();
                        head.append(String.join(",", cols));
                        if (s.dbDetails.size() < MAX_DETAIL_FILES) s.dbDetails.add(head.toString());
                        int n = 0;
                        while (rows.moveToNext() && n++ < MAX_DB_ROWS_PER_TABLE && s.dbDetails.size() < MAX_DETAIL_FILES) {
                            StringBuilder b = new StringBuilder("DATA|" + table + "|");
                            for (int i=0;i<cols.length;i++) {
                                if (i>0) b.append('|');
                                String v;
                                try { v = rows.getString(i); } catch (Throwable t) { v = ""; }
                                if (v == null) v = "";
                                if (v.length() > 500) v = v.substring(0,500);
                                b.append(v.replace('\n',' ').replace('\r',' '));
                                find(v, hits, stories);
                            }
                            s.dbDetails.add(b.toString());
                        }
                    } catch (Throwable ignored) {}
                }
            }
            c.close();
        } catch (Throwable ignored) {
            // Not every .db file is a SQLite database; normal streaming scan still handles it.
        } finally {
            if (db != null) try { db.close(); } catch (Throwable ignored) {}
        }
    }

    private boolean isUnityFs(File f) {
        try (RandomAccessFile raf = new RandomAccessFile(f, "r")) {
            byte[] sig = new byte[7];
            if (raf.read(sig) != 7) return false;
            return new String(sig, StandardCharsets.US_ASCII).equals("UnityFS");
        } catch (Throwable ignored) { return false; }
    }

    private BundleScanResult scanUnityFs(File file, Set<String> hits, Set<String> stories) throws IOException {
        BundleScanResult result = new BundleScanResult();
        try (RandomAccessFile raf = new RandomAccessFile(file, "r")) {
            String sig = readNull(raf, 64);
            if (!"UnityFS".equals(sig)) return result;
            int version = readI32(raf);
            readNull(raf, 256); // player version
            readNull(raf, 256); // engine version
            long bundleSize = readI64(raf);
            long compressedInfo = u32(readI32(raf));
            long uncompressedInfo = u32(readI32(raf));
            long flags = u32(readI32(raf));
            if (compressedInfo <= 0 || compressedInfo > UNITYFS_MAX_INFO || uncompressedInfo <= 0 || uncompressedInfo > 64L * 1024L * 1024L) return result;
            if (version >= 7) align16(raf);
            long dataStart = raf.getFilePointer();
            byte[] infoBytes;
            if ((flags & 0x80) != 0) {
                long pos = raf.length() - compressedInfo;
                if (pos < 0) return result;
                raf.seek(pos);
                infoBytes = new byte[(int)compressedInfo];
                raf.readFully(infoBytes);
                raf.seek(dataStart);
            } else {
                infoBytes = new byte[(int)compressedInfo];
                raf.readFully(infoBytes);
                dataStart = raf.getFilePointer();
            }
            byte[] info = decompressUnity(infoBytes, (int)uncompressedInfo, (int)(flags & 0x3f));
            if (info == null || info.length < 20) return result;
            int p = 16; // hash
            int blockCount = i32(info, p); p += 4;
            if (blockCount < 0 || blockCount > 100000) return result;
            int[] uSizes = new int[blockCount];
            int[] cSizes = new int[blockCount];
            int[] bFlags = new int[blockCount];
            for (int i=0;i<blockCount;i++) {
                if (p + 10 > info.length) return result;
                uSizes[i] = i32(info,p); p+=4;
                cSizes[i] = i32(info,p); p+=4;
                bFlags[i] = u16(info,p); p+=2;
                if (uSizes[i] < 0 || cSizes[i] < 0 || uSizes[i] > 8*1024*1024 || cSizes[i] > 8*1024*1024) return result;
            }
            if (p + 4 > info.length) return result;
            int nodeCount = i32(info,p); p+=4;
            if (nodeCount < 0 || nodeCount > 100000) return result;
            // We don't need the virtual file names to find wardrobe strings; skip safely.
            for (int i=0;i<nodeCount;i++) {
                if (p + 20 > info.length) return result;
                p += 8 + 8 + 4;
                int z = p; while (z < info.length && info[z] != 0) z++;
                if (z >= info.length) return result;
                p = z + 1;
            }
            raf.seek(dataStart);
            byte[] carry = new byte[4096]; int carryLen = 0;
            for (int i=0;i<blockCount;i++) {
                byte[] comp = new byte[cSizes[i]];
                raf.readFully(comp);
                byte[] raw = decompressUnity(comp, uSizes[i], bFlags[i] & 0x3f);
                if (raw == null) return result;
                result.blocks++; result.bytes += raw.length;
                byte[] combined = new byte[carryLen + raw.length];
                System.arraycopy(carry,0,combined,0,carryLen);
                System.arraycopy(raw,0,combined,carryLen,raw.length);
                String utf8 = new String(combined, StandardCharsets.UTF_8);
                String utf16 = new String(combined, StandardCharsets.UTF_16LE);
                if (containsKeyword(utf8) || containsKeyword(utf16)) result.keyword = true;
                find(utf8,hits,stories); find(utf16,hits,stories);
                carryLen = Math.min(carry.length, combined.length);
                System.arraycopy(combined, combined.length-carryLen, carry,0,carryLen);
            }
        } catch (Throwable t) { result.error = t.toString(); }
        return result;
    }

    private byte[] decompressUnity(byte[] src, int expected, int type) throws IOException {
        if (type == 0) return src;
        if (type == 2 || type == 3) return lz4Decode(src, expected);
        return null; // LZMA/LZHAM require a larger decoder; report as unsupported instead of guessing.
    }

    private byte[] lz4Decode(byte[] src, int outLen) throws IOException {
        byte[] out = new byte[outLen]; int si=0, oi=0;
        while (si < src.length && oi < outLen) {
            int token = src[si++] & 255;
            int lit = token >>> 4;
            if (lit == 15) { int x; do { if (si>=src.length) throw new IOException("LZ4 literal length"); x=src[si++]&255; lit+=x; } while(x==255); }
            if (si + lit > src.length || oi + lit > outLen) throw new IOException("LZ4 literal overflow");
            System.arraycopy(src,si,out,oi,lit); si+=lit; oi+=lit;
            if (si >= src.length) break;
            if (si+2>src.length) throw new IOException("LZ4 offset");
            int off=(src[si]&255)|((src[si+1]&255)<<8); si+=2;
            if (off<=0 || off>oi) throw new IOException("LZ4 bad offset");
            int match=(token&15)+4;
            if ((token&15)==15) { int x; do { if(si>=src.length) throw new IOException("LZ4 match length"); x=src[si++]&255; match+=x; } while(x==255); }
            if (oi+match>outLen) throw new IOException("LZ4 match overflow");
            for(int k=0;k<match;k++) out[oi+k]=out[oi-off+k];
            oi+=match;
        }
        if (oi != outLen) throw new IOException("LZ4 size mismatch: "+oi+"/"+outLen);
        return out;
    }

    private String readNull(RandomAccessFile r, int max) throws IOException {
        ByteArrayOutputStream b=new ByteArrayOutputStream();
        for(int i=0;i<max;i++){ int x=r.read(); if(x<0) throw new EOFException(); if(x==0) return b.toString("UTF-8"); b.write(x); }
        throw new IOException("UnityFS string too long");
    }
    private int readI32(RandomAccessFile r) throws IOException { return Integer.reverseBytes(r.readInt()); }
    private long readI64(RandomAccessFile r) throws IOException { return Long.reverseBytes(r.readLong()); }
    private long u32(int x) { return x & 0xffffffffL; }
    private void align16(RandomAccessFile r) throws IOException { long p=r.getFilePointer(); long q=(p+15)&~15L; r.seek(q); }
    private int i32(byte[] b,int p){ return (b[p]&255)|((b[p+1]&255)<<8)|((b[p+2]&255)<<16)|((b[p+3]&255)<<24); }
    private int u16(byte[] b,int p){ return (b[p]&255)|((b[p+1]&255)<<8); }


    private void loadMatcherCatalog() {
        if (matcherCatalog != null || context == null) return;
        synchronized (this) {
            if (matcherCatalog != null) return;
            try (InputStream in = context.getAssets().open("matcher_catalog.json")) {
                ByteArrayOutputStream b = new ByteArrayOutputStream();
                byte[] buf = new byte[65536]; int n;
                while ((n = in.read(buf)) != -1) b.write(buf,0,n);
                matcherCatalog = new MatcherCatalog(new String(b.toByteArray(), StandardCharsets.UTF_8));
            } catch (Throwable ignored) { matcherCatalog = null; }
        }
    }

    private static final class MatcherCatalog {
        final Map<String,String> storyById = new HashMap<>();
        final Map<String,List<Row>> rowsByStoryCategory = new HashMap<>();
        MatcherCatalog(String json) throws JSONException {
            JSONObject root = new JSONObject(json);
            JSONObject ids = root.getJSONObject("storyIds");
            Iterator<String> ik = ids.keys();
            while (ik.hasNext()) { String k=ik.next(); storyById.put(k, ids.getString(k)); }
            JSONObject stories = root.getJSONObject("stories");
            Iterator<String> sk = stories.keys();
            while (sk.hasNext()) {
                String story = sk.next(); JSONArray arr = stories.getJSONArray(story);
                Map<String,List<Row>> local = new HashMap<>();
                for (int i=0;i<arr.length();i++) {
                    JSONObject o=arr.getJSONObject(i);
                    String c=o.optString("c","");
                    local.computeIfAbsent(c,k->new ArrayList<>()).add(new Row(
                            o.optInt("s",0),o.optInt("e",0),o.optString("n",""),
                            o.optString("tr",""),o.optString("p",""),o.optString("b",""),
                            o.optString("a",""),o.optString("note","")
                    ));
                }
                for (Map.Entry<String,List<Row>> e: local.entrySet()) rowsByStoryCategory.put(story+"|"+e.getKey(),e.getValue());
            }
        }
        String match(String id) {
            Matcher m=ITEM.matcher(id); if(!m.matches()) return null;
            String story=storyById.get(m.group(1)); if(story==null) return null;
            String kind=m.group(2).toLowerCase(Locale.ROOT);
            int num=Integer.parseInt(m.group(3));
            String cat;
            if(kind.equals("clothes")) cat="Outfits";
            else if(kind.equals("hair")) cat="Hairstyles";
            else if(kind.equals("trinket")) cat="Accessories";
            else if(kind.contains("makeup")) cat="Makeup";
            else return null;
            List<Row> rows=rowsByStoryCategory.get(story+"|"+cat);
            if(rows==null || num<1 || num>rows.size()) return story+"|"+cat+"|ID="+num+"|UNRESOLVED|category has "+(rows==null?0:rows.size())+" rows";
            Row r=rows.get(num-1);
            return story+"|"+cat+"|ID="+num+"|CANDIDATE|S"+r.s+"E"+r.e+"|"+r.name+"|"+r.price+"|"+r.acq+"|"+r.note;
        }
        static final class Row { final int s,e; final String name,tr,price,bulk,acq,note; Row(int s,int e,String name,String tr,String price,String bulk,String acq,String note){this.s=s;this.e=e;this.name=name;this.tr=tr;this.price=price;this.bulk=bulk;this.acq=acq;this.note=note;} }
    }

    @Override public void destroy() { System.exit(0); }

    private static final class ScanState {
        long bytes, scannedBytes, unityBytes;
        int files, scannedFiles, skippedFiles, errors, keywordFiles, dbFiles, dbTables, dbWardrobeTables, unityBundles, unityBlocks, unityKeywordBundles, unityErrors, accountFiles;
        final TreeSet<String> storyIds = new TreeSet<>();
        final TreeSet<String> uniqueItems = new TreeSet<>();
        final ArrayList<String> details = new ArrayList<>();
        final ArrayList<String> candidates = new ArrayList<>();
        final ArrayList<String> dbDetails = new ArrayList<>();
        final ArrayList<String> evidence = new ArrayList<>();
        final ArrayList<String> accountAcomp = new ArrayList<>();
        final ArrayList<String> accountApks = new ArrayList<>();
        final ArrayList<String> accountPairs = new ArrayList<>();
        final ArrayList<String> matches = new ArrayList<>();
        final ArrayList<String> evidenceSummaries = new ArrayList<>();
    }
    private static final class EvidenceAgg {
        final Set<String> files = new HashSet<>();
        int trueSignals, falseSignals;
    }
    private static final class ScanFileResult {
        final boolean keyword;
        ScanFileResult(boolean keyword) { this.keyword = keyword; }
    }
    private static final class BundleScanResult {
        int blocks;
        long bytes;
        boolean keyword;
        String error;
    }
}
