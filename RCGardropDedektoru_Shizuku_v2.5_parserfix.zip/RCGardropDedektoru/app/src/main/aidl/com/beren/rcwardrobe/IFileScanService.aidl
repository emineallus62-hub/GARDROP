package com.beren.rcwardrobe;

interface IFileScanService {
    String scan(String root);
    // Shizuku reserves this transaction for stopping UserService.
    void destroy() = 16777114;
}
