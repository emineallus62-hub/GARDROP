# RC Gardırop Dedektörü — v2.2 build notu

Bu proje Android Studio gerektirmeden GitHub Actions üzerinde debug APK üretmek için hazırlanmıştır.

## GitHub tarafında

1. ZIP'i deponun köküne yükleyin.
2. `.github/workflows/build.yml` dosyası deponun kökündeki workflow olarak bulunmalıdır.
3. Actions → **Build APK** → **Run workflow** ile elle başlatılabilir.
4. Başarılı çalışmada **Artifacts** altında `RC-Gardrop-Dedektoru-v2.2` görünür.

Workflow; Java 17, Gradle 8.7 ve Android SDK 35'i açıkça kurar/kontrol eder. `android.nonTransitiveRClass` gibi geçersiz proje ayarlarını kabul etmez.
